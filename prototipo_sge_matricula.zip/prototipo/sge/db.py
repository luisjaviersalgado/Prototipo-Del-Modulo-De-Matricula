"""Base de datos del prototipo: esquema, conexión y datos de ejemplo (SQLite)."""
import os
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS estudiantes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    programa TEXT NOT NULL,
    saldo_pendiente REAL NOT NULL DEFAULT 0 CHECK (saldo_pendiente >= 0)
);
CREATE TABLE IF NOT EXISTS cursos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    codigo TEXT NOT NULL UNIQUE,
    nombre TEXT NOT NULL,
    creditos INTEGER NOT NULL CHECK (creditos > 0),
    cupo_maximo INTEGER NOT NULL CHECK (cupo_maximo >= 0)
);
CREATE TABLE IF NOT EXISTS horarios (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    curso_id INTEGER NOT NULL REFERENCES cursos(id),
    dia TEXT NOT NULL CHECK (dia IN ('LUN','MAR','MIE','JUE','VIE','SAB')),
    hora_inicio INTEGER NOT NULL,
    hora_fin INTEGER NOT NULL,
    CHECK (hora_inicio < hora_fin)
);
CREATE TABLE IF NOT EXISTS prerrequisitos (
    curso_id INTEGER NOT NULL REFERENCES cursos(id),
    prerrequisito_id INTEGER NOT NULL REFERENCES cursos(id),
    PRIMARY KEY (curso_id, prerrequisito_id)
);
CREATE TABLE IF NOT EXISTS historial (
    estudiante_id INTEGER NOT NULL REFERENCES estudiantes(id),
    curso_id INTEGER NOT NULL REFERENCES cursos(id),
    nota REAL NOT NULL CHECK (nota >= 0 AND nota <= 5),
    PRIMARY KEY (estudiante_id, curso_id)
);
CREATE TABLE IF NOT EXISTS matriculas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    estudiante_id INTEGER NOT NULL REFERENCES estudiantes(id),
    curso_id INTEGER NOT NULL REFERENCES cursos(id),
    periodo TEXT NOT NULL,
    estado TEXT NOT NULL CHECK (estado IN ('ACTIVA','CANCELADA')),
    creada_en TEXT NOT NULL,
    UNIQUE (estudiante_id, curso_id, periodo)
);
CREATE TABLE IF NOT EXISTS auditoria (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    evento TEXT NOT NULL,
    estudiante_id INTEGER,
    curso_id INTEGER,
    detalle TEXT,
    creada_en TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_matriculas_curso ON matriculas (curso_id, periodo, estado);
CREATE INDEX IF NOT EXISTS idx_matriculas_est ON matriculas (estudiante_id, periodo, estado);
CREATE INDEX IF NOT EXISTS idx_horarios_curso ON horarios (curso_id);
"""


def connect(path):
    """Conexión en modo autocommit; las transacciones se abren de forma explícita."""
    con = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.execute("PRAGMA journal_mode = WAL")
    con.execute("PRAGMA synchronous = NORMAL")
    con.execute("PRAGMA busy_timeout = 30000")
    return con


def init_db(path):
    if os.path.exists(path):
        os.remove(path)
    con = connect(path)
    con.executescript(SCHEMA)
    con.close()


# ---------------------------------------------------------------- datos de ejemplo
CURSOS_DEMO = [
    # codigo, nombre, creditos, cupo, [(dia, ini, fin)], [prerrequisitos]
    ("IS101", "Programación I", 3, 30, [("LUN", 8, 10), ("MIE", 8, 10)], []),
    ("IS102", "Cálculo I", 4, 40, [("MAR", 8, 10), ("JUE", 8, 10)], []),
    ("IS103", "Lógica Discreta", 3, 30, [("LUN", 10, 12)], []),
    ("IS104", "Comunicación Oral", 2, 40, [("VIE", 8, 10)], []),
    ("IS105", "Ética Profesional (electiva)", 2, 30, [("MIE", 10, 12)], []),
    ("IS201", "Programación II", 3, 25, [("MIE", 10, 12), ("VIE", 10, 12)], ["IS101"]),
    ("IS202", "Estructuras de Datos", 4, 25, [("MAR", 10, 12), ("JUE", 10, 12)], ["IS201"]),
    ("IS203", "Bases de Datos I", 3, 25, [("MIE", 8, 10)], ["IS101", "IS103"]),
    ("IS204", "Cálculo II", 4, 30, [("MAR", 14, 16), ("JUE", 14, 16)], ["IS102"]),
    ("IS301", "Ingeniería de Requisitos", 3, 20, [("LUN", 14, 16)], ["IS203"]),
    ("IS302", "Gestión de Proyectos de Software", 3, 20, [("VIE", 14, 16)], ["IS201"]),
    ("IS303", "Seguridad en Software", 3, 20, [("MIE", 14, 16)], ["IS203"]),
    ("IS304", "Arquitectura de Software", 3, 15, [("JUE", 16, 18)], ["IS202", "IS203"]),
    ("IS401", "Inteligencia Artificial", 3, 15, [("LUN", 16, 18)], ["IS202"]),
]

ESTUDIANTES_DEMO = [
    # codigo, nombre, saldo_pendiente, historial {curso: nota}
    ("E001", "Ana Torres", 0, {"IS101": 4.2, "IS102": 3.5, "IS103": 3.8}),
    ("E002", "Bruno Díaz", 0, {}),
    ("E003", "Carla Ríos", 0, {"IS101": 2.8, "IS102": 3.1}),
    ("E004", "Diego Mora", 0, {"IS101": 3.0, "IS103": 4.0}),
    ("E005", "Elena Vega", 350000, {"IS101": 4.0, "IS102": 3.9, "IS103": 4.5, "IS201": 4.0, "IS203": 3.9}),
    ("E006", "Felipe Rojas", 0, {"IS101": 4.1, "IS102": 3.8, "IS103": 3.6, "IS201": 4.0, "IS203": 3.7}),
    ("E007", "Gabriela Núñez", 0, {"IS101": 3.9, "IS102": 4.4}),
    ("E008", "Hugo Castaño", 0, {"IS101": 3.2}),
]


def seed_demo(path):
    con = connect(path)
    ids = {}
    for cod, nom, cred, cupo, horarios, _ in CURSOS_DEMO:
        cur = con.execute("INSERT INTO cursos (codigo, nombre, creditos, cupo_maximo) VALUES (?,?,?,?)",
                          (cod, nom, cred, cupo))
        ids[cod] = cur.lastrowid
        for dia, ini, fin in horarios:
            con.execute("INSERT INTO horarios (curso_id, dia, hora_inicio, hora_fin) VALUES (?,?,?,?)",
                        (cur.lastrowid, dia, ini, fin))
    for cod, _, _, _, _, prereqs in CURSOS_DEMO:
        for p in prereqs:
            con.execute("INSERT INTO prerrequisitos (curso_id, prerrequisito_id) VALUES (?,?)", (ids[cod], ids[p]))
    for cod, nom, saldo, hist in ESTUDIANTES_DEMO:
        cur = con.execute("INSERT INTO estudiantes (codigo, nombre, programa, saldo_pendiente) VALUES (?,?,?,?)",
                          (cod, nom, "Ingeniería de Software", saldo))
        for c, nota in hist.items():
            con.execute("INSERT INTO historial (estudiante_id, curso_id, nota) VALUES (?,?,?)", (cur.lastrowid, ids[c], nota))
    con.close()


def seed_carga(path, n_estudiantes=500, n_cursos=40, cupo=400, cupo_pico=100):
    """Datos para la prueba de carga: 40 cursos con un horario único cada uno (sin cruces),
    500 estudiantes sin deuda y un curso extra de cupo limitado para probar la concurrencia."""
    con = connect(path)
    dias = ["LUN", "MAR", "MIE", "JUE", "VIE"]
    bloques = [(6, 8), (8, 10), (10, 12), (12, 14), (14, 16), (16, 18), (18, 20), (20, 22)]
    slots = [(d, a, b) for d in dias for a, b in bloques]
    con.execute("BEGIN")
    for i in range(n_cursos):
        cur = con.execute("INSERT INTO cursos (codigo, nombre, creditos, cupo_maximo) VALUES (?,?,?,?)",
                          (f"C{i+1:03d}", f"Curso {i+1}", 3, cupo))
        d, a, b = slots[i]
        con.execute("INSERT INTO horarios (curso_id, dia, hora_inicio, hora_fin) VALUES (?,?,?,?)", (cur.lastrowid, d, a, b))
    cur = con.execute("INSERT INTO cursos (codigo, nombre, creditos, cupo_maximo) VALUES (?,?,?,?)",
                      ("PICO", "Curso de cupo limitado", 3, cupo_pico))
    con.execute("INSERT INTO horarios (curso_id, dia, hora_inicio, hora_fin) VALUES (?,?,?,?)", (cur.lastrowid, "SAB", 8, 10))
    for i in range(n_estudiantes):
        con.execute("INSERT INTO estudiantes (codigo, nombre, programa, saldo_pendiente) VALUES (?,?,?,0)",
                    (f"P{i+1:04d}", f"Estudiante {i+1}", "Ingeniería"))
    con.execute("COMMIT")
    con.close()
