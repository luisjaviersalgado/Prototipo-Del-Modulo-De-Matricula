"""Reglas de negocio de la matrícula.

Toda la validación y la escritura ocurren dentro de una sola transacción
(BEGIN IMMEDIATE), de modo que dos solicitudes simultáneas no puedan ocupar el mismo cupo.
"""
from datetime import datetime

PERIODO = "2026-2"
NOTA_MINIMA = 3.0        # nota mínima aprobatoria (escala de 0 a 5)
MAX_CREDITOS = 20        # máximo de créditos por periodo


class ReglaError(Exception):
    def __init__(self, status, codigo, mensaje, detalle=None):
        super().__init__(mensaje)
        self.status = status
        self.codigo = codigo
        self.mensaje = mensaje
        self.detalle = detalle


def _ahora():
    return datetime.now().isoformat(timespec="seconds")


def auditar(con, evento, estudiante_id=None, curso_id=None, detalle=None):
    con.execute(
        "INSERT INTO auditoria (evento, estudiante_id, curso_id, detalle, creada_en) VALUES (?,?,?,?,?)",
        (evento, estudiante_id, curso_id, detalle, _ahora()),
    )


def _validar_y_matricular(con, estudiante_id, curso_id, periodo):
    est = con.execute("SELECT * FROM estudiantes WHERE id = ?", (estudiante_id,)).fetchone()
    if est is None:
        raise ReglaError(404, "ESTUDIANTE_NO_ENCONTRADO", "El estudiante no existe.")
    curso = con.execute("SELECT * FROM cursos WHERE id = ?", (curso_id,)).fetchone()
    if curso is None:
        raise ReglaError(404, "CURSO_NO_ENCONTRADO", "El curso no existe.")

    # 1. Sin deuda pendiente
    if est["saldo_pendiente"] > 0:
        raise ReglaError(409, "PAGO_PENDIENTE",
                         "Tiene un saldo pendiente y no puede matricularse hasta ponerse al día.",
                         {"saldo_pendiente": est["saldo_pendiente"]})

    # 2. No estar ya matriculado en el mismo periodo
    previa = con.execute(
        "SELECT id, estado FROM matriculas WHERE estudiante_id = ? AND curso_id = ? AND periodo = ?",
        (estudiante_id, curso_id, periodo)).fetchone()
    if previa is not None and previa["estado"] == "ACTIVA":
        raise ReglaError(409, "YA_MATRICULADO", "Ya está matriculado en este curso.")

    # 3. Prerrequisitos aprobados (nota >= NOTA_MINIMA)
    faltan = con.execute(
        """SELECT c.codigo FROM prerrequisitos p
           JOIN cursos c ON c.id = p.prerrequisito_id
           WHERE p.curso_id = ?
             AND NOT EXISTS (SELECT 1 FROM historial h
                             WHERE h.estudiante_id = ? AND h.curso_id = p.prerrequisito_id AND h.nota >= ?)
           ORDER BY c.codigo""",
        (curso_id, estudiante_id, NOTA_MINIMA)).fetchall()
    if faltan:
        codigos = [f["codigo"] for f in faltan]
        raise ReglaError(422, "PRERREQUISITOS_PENDIENTES",
                         "Faltan prerrequisitos aprobados: " + ", ".join(codigos) + ".",
                         {"faltan": codigos})

    # 4. Cupo disponible
    ocupados = con.execute(
        "SELECT COUNT(*) AS n FROM matriculas WHERE curso_id = ? AND periodo = ? AND estado = 'ACTIVA'",
        (curso_id, periodo)).fetchone()["n"]
    if ocupados >= curso["cupo_maximo"]:
        raise ReglaError(409, "SIN_CUPO", "El curso no tiene cupos disponibles.",
                         {"cupo_maximo": curso["cupo_maximo"]})

    # 5. Límite de créditos por periodo
    actuales = con.execute(
        """SELECT COALESCE(SUM(c.creditos), 0) AS total FROM matriculas m
           JOIN cursos c ON c.id = m.curso_id
           WHERE m.estudiante_id = ? AND m.periodo = ? AND m.estado = 'ACTIVA'""",
        (estudiante_id, periodo)).fetchone()["total"]
    if actuales + curso["creditos"] > MAX_CREDITOS:
        raise ReglaError(409, "LIMITE_CREDITOS",
                         f"Superaría el máximo de {MAX_CREDITOS} créditos por periodo.",
                         {"creditos_actuales": actuales, "creditos_curso": curso["creditos"]})

    # 6. Sin cruce de horario (dos franjas se cruzan si una empieza antes de que la otra termine)
    cruce = con.execute(
        """SELECT DISTINCT c.codigo FROM horarios nuevo
           JOIN horarios h ON h.dia = nuevo.dia AND h.hora_inicio < nuevo.hora_fin AND nuevo.hora_inicio < h.hora_fin
           JOIN matriculas m ON m.curso_id = h.curso_id
           JOIN cursos c ON c.id = h.curso_id
           WHERE nuevo.curso_id = ? AND m.estudiante_id = ? AND m.periodo = ? AND m.estado = 'ACTIVA'
           ORDER BY c.codigo""",
        (curso_id, estudiante_id, periodo)).fetchall()
    if cruce:
        codigos = [c["codigo"] for c in cruce]
        raise ReglaError(409, "CRUCE_HORARIO", "Se cruza con el horario de: " + ", ".join(codigos) + ".",
                         {"cursos_en_conflicto": codigos})

    # Todo en regla: registrar (o reactivar una matrícula cancelada)
    if previa is not None:
        con.execute("UPDATE matriculas SET estado = 'ACTIVA', creada_en = ? WHERE id = ?", (_ahora(), previa["id"]))
        matricula_id = previa["id"]
    else:
        cur = con.execute(
            "INSERT INTO matriculas (estudiante_id, curso_id, periodo, estado, creada_en) VALUES (?,?,?, 'ACTIVA', ?)",
            (estudiante_id, curso_id, periodo, _ahora()))
        matricula_id = cur.lastrowid
    auditar(con, "MATRICULA_CREADA", estudiante_id, curso_id, f"periodo {periodo}")
    return {"id": matricula_id, "estudiante_id": estudiante_id, "curso_id": curso_id,
            "curso": curso["codigo"], "periodo": periodo, "estado": "ACTIVA",
            "creditos_totales": actuales + curso["creditos"]}


def matricular(con, estudiante_id, curso_id, periodo=PERIODO):
    con.execute("BEGIN IMMEDIATE")
    try:
        resultado = _validar_y_matricular(con, estudiante_id, curso_id, periodo)
        con.execute("COMMIT")
        return resultado
    except ReglaError as e:
        con.execute("ROLLBACK")
        auditar(con, "MATRICULA_RECHAZADA", estudiante_id, curso_id, e.codigo)
        raise
    except Exception:
        con.execute("ROLLBACK")
        raise


def cancelar(con, matricula_id):
    con.execute("BEGIN IMMEDIATE")
    try:
        m = con.execute("SELECT * FROM matriculas WHERE id = ?", (matricula_id,)).fetchone()
        if m is None:
            raise ReglaError(404, "MATRICULA_NO_ENCONTRADA", "La matrícula no existe.")
        if m["estado"] == "CANCELADA":
            raise ReglaError(409, "YA_CANCELADA", "La matrícula ya estaba cancelada.")
        con.execute("UPDATE matriculas SET estado = 'CANCELADA' WHERE id = ?", (matricula_id,))
        auditar(con, "MATRICULA_CANCELADA", m["estudiante_id"], m["curso_id"])
        con.execute("COMMIT")
        return {"id": matricula_id, "estado": "CANCELADA"}
    except ReglaError:
        con.execute("ROLLBACK")
        raise
    except Exception:
        con.execute("ROLLBACK")
        raise
