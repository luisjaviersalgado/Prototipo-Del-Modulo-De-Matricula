"""Prototipo del módulo de matrícula del Sistema de Gestión Educativa «EduTech Solutions»."""
import os

from flask import Flask, g, jsonify, request

from . import db, matricula
from .matricula import ReglaError

BASE = os.path.dirname(os.path.abspath(__file__))


def create_app(db_path=None):
    app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
    app.config["DB_PATH"] = db_path or os.path.join(os.path.dirname(BASE), "sge.db")
    if not os.path.exists(app.config["DB_PATH"]):
        db.init_db(app.config["DB_PATH"])
        db.seed_demo(app.config["DB_PATH"])

    def con():
        if "con" not in g:
            g.con = db.connect(app.config["DB_PATH"])
        return g.con

    @app.teardown_appcontext
    def cerrar(_exc):
        c = g.pop("con", None)
        if c is not None:
            c.close()

    @app.errorhandler(ReglaError)
    def regla_error(e):
        return jsonify({"error": {"codigo": e.codigo, "mensaje": e.mensaje, "detalle": e.detalle}}), e.status

    def entero(valor, nombre):
        if isinstance(valor, bool) or not isinstance(valor, int):
            raise ReglaError(400, "DATOS_INVALIDOS", f"El campo «{nombre}» es obligatorio y debe ser un número entero.")
        return valor

    # ------------------------------------------------------------------ páginas
    @app.get("/")
    def inicio():
        return app.send_static_file("index.html")

    # ------------------------------------------------------------------ API
    @app.get("/api/salud")
    def salud():
        con().execute("SELECT 1").fetchone()
        return jsonify({"estado": "ok"})

    @app.get("/api/estudiantes")
    def estudiantes():
        filas = con().execute("SELECT id, codigo, nombre, programa, saldo_pendiente FROM estudiantes ORDER BY codigo").fetchall()
        return jsonify([dict(f) for f in filas])

    @app.get("/api/cursos")
    def cursos():
        est = request.args.get("estudiante_id", type=int)
        c = con()
        filas = c.execute(
            """SELECT c.id, c.codigo, c.nombre, c.creditos, c.cupo_maximo,
                      (SELECT COUNT(*) FROM matriculas m
                        WHERE m.curso_id = c.id AND m.periodo = ? AND m.estado = 'ACTIVA') AS ocupados
               FROM cursos c ORDER BY c.codigo""", (matricula.PERIODO,)).fetchall()
        horarios = {}
        for h in c.execute("SELECT curso_id, dia, hora_inicio, hora_fin FROM horarios ORDER BY curso_id, CASE dia WHEN 'LUN' THEN 1 WHEN 'MAR' THEN 2 WHEN 'MIE' THEN 3 WHEN 'JUE' THEN 4 WHEN 'VIE' THEN 5 ELSE 6 END, hora_inicio"):
            horarios.setdefault(h["curso_id"], []).append(f'{h["dia"]} {h["hora_inicio"]:02d}-{h["hora_fin"]:02d}')
        prereqs = {}
        for p in c.execute("SELECT p.curso_id, c.codigo FROM prerrequisitos p JOIN cursos c ON c.id = p.prerrequisito_id ORDER BY c.codigo"):
            prereqs.setdefault(p["curso_id"], []).append(p["codigo"])
        propios = set()
        if est is not None:
            propios = {r["curso_id"] for r in c.execute(
                "SELECT curso_id FROM matriculas WHERE estudiante_id = ? AND periodo = ? AND estado = 'ACTIVA'",
                (est, matricula.PERIODO))}
        return jsonify([{
            "id": f["id"], "codigo": f["codigo"], "nombre": f["nombre"], "creditos": f["creditos"],
            "cupo_maximo": f["cupo_maximo"], "cupo_disponible": f["cupo_maximo"] - f["ocupados"],
            "horarios": horarios.get(f["id"], []), "prerrequisitos": prereqs.get(f["id"], []),
            "matriculado": f["id"] in propios,
        } for f in filas])

    @app.get("/api/estudiantes/<int:estudiante_id>/matriculas")
    def matriculas_de(estudiante_id):
        c = con()
        if c.execute("SELECT 1 FROM estudiantes WHERE id = ?", (estudiante_id,)).fetchone() is None:
            raise ReglaError(404, "ESTUDIANTE_NO_ENCONTRADO", "El estudiante no existe.")
        filas = c.execute(
            """SELECT m.id, c.codigo, c.nombre, c.creditos, m.periodo FROM matriculas m
               JOIN cursos c ON c.id = m.curso_id
               WHERE m.estudiante_id = ? AND m.periodo = ? AND m.estado = 'ACTIVA' ORDER BY c.codigo""",
            (estudiante_id, matricula.PERIODO)).fetchall()
        lista = [dict(f) for f in filas]
        return jsonify({"matriculas": lista, "creditos_totales": sum(f["creditos"] for f in lista),
                        "maximo_creditos": matricula.MAX_CREDITOS})

    @app.post("/api/matriculas")
    def crear_matricula():
        cuerpo = request.get_json(silent=True)
        if not isinstance(cuerpo, dict):
            raise ReglaError(400, "DATOS_INVALIDOS", "El cuerpo debe ser un JSON con estudiante_id y curso_id.")
        e = entero(cuerpo.get("estudiante_id"), "estudiante_id")
        k = entero(cuerpo.get("curso_id"), "curso_id")
        return jsonify(matricula.matricular(con(), e, k)), 201

    @app.delete("/api/matriculas/<int:matricula_id>")
    def cancelar_matricula(matricula_id):
        return jsonify(matricula.cancelar(con(), matricula_id))

    @app.get("/api/reportes/ocupacion")
    def ocupacion():
        filas = con().execute(
            """SELECT c.codigo, c.nombre, c.cupo_maximo,
                      (SELECT COUNT(*) FROM matriculas m WHERE m.curso_id = c.id AND m.periodo = ? AND m.estado = 'ACTIVA') AS ocupados
               FROM cursos c ORDER BY c.codigo""", (matricula.PERIODO,)).fetchall()
        return jsonify([{"codigo": f["codigo"], "nombre": f["nombre"], "cupo_maximo": f["cupo_maximo"],
                         "ocupados": f["ocupados"],
                         "ocupacion_pct": round(100 * f["ocupados"] / f["cupo_maximo"], 1) if f["cupo_maximo"] else 0}
                        for f in filas])

    return app
