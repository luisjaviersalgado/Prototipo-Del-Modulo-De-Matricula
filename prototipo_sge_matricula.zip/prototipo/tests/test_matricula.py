"""Pruebas automáticas del módulo de matrícula.

Ejecutar:  python -m unittest discover -s tests -v
"""
import os
import sys
import tempfile
import threading
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sge import create_app, db  # noqa: E402
from sge.matricula import MAX_CREDITOS  # noqa: E402


class BaseTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.dir.name, "prueba.db")
        db.init_db(self.path)
        self.con = db.connect(self.path)
        self.app = create_app(self.path)
        self.client = self.app.test_client()

    def tearDown(self):
        self.con.close()
        self.dir.cleanup()

    # --- ayudas para armar datos
    def estudiante(self, codigo="E1", saldo=0):
        return self.con.execute(
            "INSERT INTO estudiantes (codigo, nombre, programa, saldo_pendiente) VALUES (?,?,?,?)",
            (codigo, "Estudiante " + codigo, "Ingeniería", saldo)).lastrowid

    def curso(self, codigo, creditos=3, cupo=10, horarios=(("LUN", 8, 10),), prereqs=()):
        cid = self.con.execute("INSERT INTO cursos (codigo, nombre, creditos, cupo_maximo) VALUES (?,?,?,?)",
                               (codigo, "Curso " + codigo, creditos, cupo)).lastrowid
        for d, a, b in horarios:
            self.con.execute("INSERT INTO horarios (curso_id, dia, hora_inicio, hora_fin) VALUES (?,?,?,?)", (cid, d, a, b))
        for p in prereqs:
            self.con.execute("INSERT INTO prerrequisitos (curso_id, prerrequisito_id) VALUES (?,?)", (cid, p))
        return cid

    def nota(self, est, curso, valor):
        self.con.execute("INSERT INTO historial (estudiante_id, curso_id, nota) VALUES (?,?,?)", (est, curso, valor))

    def matricular(self, est, curso):
        return self.client.post("/api/matriculas", json={"estudiante_id": est, "curso_id": curso})

    def codigo_error(self, resp):
        return resp.get_json()["error"]["codigo"]


class TestReglas(BaseTest):
    def test_matricula_exitosa(self):
        e, c = self.estudiante(), self.curso("A1")
        r = self.matricular(e, c)
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.get_json()["estado"], "ACTIVA")
        self.assertEqual(r.get_json()["creditos_totales"], 3)

    def test_matricula_duplicada(self):
        e, c = self.estudiante(), self.curso("A1")
        self.matricular(e, c)
        r = self.matricular(e, c)
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "YA_MATRICULADO"))

    def test_estudiante_inexistente(self):
        c = self.curso("A1")
        r = self.matricular(999, c)
        self.assertEqual((r.status_code, self.codigo_error(r)), (404, "ESTUDIANTE_NO_ENCONTRADO"))

    def test_curso_inexistente(self):
        e = self.estudiante()
        r = self.matricular(e, 999)
        self.assertEqual((r.status_code, self.codigo_error(r)), (404, "CURSO_NO_ENCONTRADO"))

    def test_pago_pendiente_bloquea(self):
        e, c = self.estudiante(saldo=150000), self.curso("A1")
        r = self.matricular(e, c)
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "PAGO_PENDIENTE"))

    def test_prerrequisito_no_cursado(self):
        e = self.estudiante()
        base = self.curso("A1")
        avanzado = self.curso("A2", horarios=(("MAR", 8, 10),), prereqs=(base,))
        r = self.matricular(e, avanzado)
        self.assertEqual((r.status_code, self.codigo_error(r)), (422, "PRERREQUISITOS_PENDIENTES"))
        self.assertEqual(r.get_json()["error"]["detalle"]["faltan"], ["A1"])

    def test_prerrequisito_nota_limite(self):
        """La nota mínima aprobatoria es 3,0: con 3,0 se puede matricular, con 2,9 no."""
        base = self.curso("A1")
        avanzado = self.curso("A2", horarios=(("MAR", 8, 10),), prereqs=(base,))
        aprobado, reprobado = self.estudiante("E1"), self.estudiante("E2")
        self.nota(aprobado, base, 3.0)
        self.nota(reprobado, base, 2.9)
        self.assertEqual(self.matricular(aprobado, avanzado).status_code, 201)
        r = self.matricular(reprobado, avanzado)
        self.assertEqual((r.status_code, self.codigo_error(r)), (422, "PRERREQUISITOS_PENDIENTES"))

    def test_varios_prerrequisitos_informa_los_que_faltan(self):
        e = self.estudiante()
        p1, p2 = self.curso("P1"), self.curso("P2", horarios=(("MAR", 8, 10),))
        c = self.curso("C1", horarios=(("MIE", 8, 10),), prereqs=(p1, p2))
        self.nota(e, p1, 4.0)
        r = self.matricular(e, c)
        self.assertEqual(r.get_json()["error"]["detalle"]["faltan"], ["P2"])

    def test_sin_cupo(self):
        c = self.curso("A1", cupo=1)
        e1, e2 = self.estudiante("E1"), self.estudiante("E2")
        self.assertEqual(self.matricular(e1, c).status_code, 201)
        r = self.matricular(e2, c)
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "SIN_CUPO"))

    def test_cruce_de_horario(self):
        e = self.estudiante()
        a = self.curso("A1", horarios=(("LUN", 8, 10),))
        b = self.curso("B1", horarios=(("LUN", 9, 11),))
        self.matricular(e, a)
        r = self.matricular(e, b)
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "CRUCE_HORARIO"))
        self.assertEqual(r.get_json()["error"]["detalle"]["cursos_en_conflicto"], ["A1"])

    def test_horarios_consecutivos_no_se_cruzan(self):
        e = self.estudiante()
        a = self.curso("A1", horarios=(("LUN", 8, 10),))
        b = self.curso("B1", horarios=(("LUN", 10, 12),))
        self.matricular(e, a)
        self.assertEqual(self.matricular(e, b).status_code, 201)

    def test_mismo_horario_otro_dia_no_se_cruza(self):
        e = self.estudiante()
        a = self.curso("A1", horarios=(("LUN", 8, 10),))
        b = self.curso("B1", horarios=(("MAR", 8, 10),))
        self.matricular(e, a)
        self.assertEqual(self.matricular(e, b).status_code, 201)

    def test_limite_de_creditos(self):
        e = self.estudiante()
        dias = ["LUN", "MAR", "MIE", "JUE", "VIE", "SAB"]
        cursos = [self.curso(f"C{i}", creditos=4, horarios=((dias[i], 8, 10),)) for i in range(6)]
        for c in cursos[:5]:                      # 5 x 4 = 20 créditos, el máximo permitido
            self.assertEqual(self.matricular(e, c).status_code, 201)
        r = self.matricular(e, cursos[5])
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "LIMITE_CREDITOS"))
        self.assertEqual(MAX_CREDITOS, 20)

    def test_entrada_invalida(self):
        for cuerpo in ({}, {"estudiante_id": 1}, {"estudiante_id": "uno", "curso_id": 1},
                       {"estudiante_id": True, "curso_id": 1}):
            r = self.client.post("/api/matriculas", json=cuerpo)
            self.assertEqual((r.status_code, self.codigo_error(r)), (400, "DATOS_INVALIDOS"), cuerpo)
        r = self.client.post("/api/matriculas", data="no es json", content_type="text/plain")
        self.assertEqual(r.status_code, 400)


class TestCancelacion(BaseTest):
    def test_cancelar_libera_cupo(self):
        c = self.curso("A1", cupo=1)
        e1, e2 = self.estudiante("E1"), self.estudiante("E2")
        m = self.matricular(e1, c).get_json()["id"]
        self.assertEqual(self.matricular(e2, c).status_code, 409)
        self.assertEqual(self.client.delete(f"/api/matriculas/{m}").status_code, 200)
        self.assertEqual(self.matricular(e2, c).status_code, 201)

    def test_cancelar_dos_veces(self):
        e, c = self.estudiante(), self.curso("A1")
        m = self.matricular(e, c).get_json()["id"]
        self.client.delete(f"/api/matriculas/{m}")
        r = self.client.delete(f"/api/matriculas/{m}")
        self.assertEqual((r.status_code, self.codigo_error(r)), (409, "YA_CANCELADA"))

    def test_cancelar_inexistente(self):
        r = self.client.delete("/api/matriculas/12345")
        self.assertEqual((r.status_code, self.codigo_error(r)), (404, "MATRICULA_NO_ENCONTRADA"))

    def test_rematricula_tras_cancelar(self):
        e, c = self.estudiante(), self.curso("A1")
        m = self.matricular(e, c).get_json()["id"]
        self.client.delete(f"/api/matriculas/{m}")
        r = self.matricular(e, c)
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.get_json()["id"], m)   # se reactiva la misma matrícula

    def test_cancelar_libera_horario_y_creditos(self):
        e = self.estudiante()
        a = self.curso("A1", horarios=(("LUN", 8, 10),))
        b = self.curso("B1", horarios=(("LUN", 8, 10),))
        m = self.matricular(e, a).get_json()["id"]
        self.assertEqual(self.matricular(e, b).status_code, 409)
        self.client.delete(f"/api/matriculas/{m}")
        self.assertEqual(self.matricular(e, b).status_code, 201)


class TestConsultasYAuditoria(BaseTest):
    def test_listado_de_cursos_muestra_cupos_y_matricula_propia(self):
        e, c = self.estudiante(), self.curso("A1", cupo=5)
        self.matricular(e, c)
        cursos = self.client.get(f"/api/cursos?estudiante_id={e}").get_json()
        self.assertEqual(cursos[0]["cupo_disponible"], 4)
        self.assertTrue(cursos[0]["matriculado"])

    def test_matriculas_del_estudiante(self):
        e = self.estudiante()
        self.matricular(e, self.curso("A1", creditos=3))
        self.matricular(e, self.curso("B1", creditos=4, horarios=(("MAR", 8, 10),)))
        datos = self.client.get(f"/api/estudiantes/{e}/matriculas").get_json()
        self.assertEqual(datos["creditos_totales"], 7)
        self.assertEqual(len(datos["matriculas"]), 2)

    def test_reporte_de_ocupacion(self):
        c = self.curso("A1", cupo=4)
        for i in range(3):
            self.matricular(self.estudiante(f"E{i}"), c)
        fila = self.client.get("/api/reportes/ocupacion").get_json()[0]
        self.assertEqual((fila["ocupados"], fila["ocupacion_pct"]), (3, 75.0))

    def test_auditoria_registra_exitos_rechazos_y_cancelaciones(self):
        e, c = self.estudiante(), self.curso("A1")
        m = self.matricular(e, c).get_json()["id"]
        self.matricular(e, c)                                  # rechazo por duplicado
        self.client.delete(f"/api/matriculas/{m}")
        eventos = [f["evento"] for f in self.con.execute("SELECT evento FROM auditoria ORDER BY id")]
        self.assertEqual(eventos, ["MATRICULA_CREADA", "MATRICULA_RECHAZADA", "MATRICULA_CANCELADA"])

    def test_pagina_inicial_y_salud(self):
        self.assertEqual(self.client.get("/api/salud").get_json(), {"estado": "ok"})
        with self.client.get("/") as r:
            self.assertEqual(r.status_code, 200)


class TestConcurrencia(BaseTest):
    def _rafaga(self, curso, estudiantes):
        resultados = []
        lock = threading.Lock()
        inicio = threading.Barrier(len(estudiantes))

        def intento(est):
            cliente = self.app.test_client()
            inicio.wait()
            r = cliente.post("/api/matriculas", json={"estudiante_id": est, "curso_id": curso})
            with lock:
                resultados.append(r.status_code)

        hilos = [threading.Thread(target=intento, args=(e,)) for e in estudiantes]
        for h in hilos:
            h.start()
        for h in hilos:
            h.join()
        return resultados

    def test_cupo_no_se_sobrepasa_con_solicitudes_simultaneas(self):
        """40 estudiantes piden a la vez un curso con 5 cupos: deben entrar exactamente 5."""
        c = self.curso("A1", cupo=5)
        estudiantes = [self.estudiante(f"E{i}") for i in range(40)]
        resultados = self._rafaga(c, estudiantes)
        self.assertEqual(resultados.count(201), 5)
        self.assertEqual(resultados.count(409), 35)
        activas = self.con.execute("SELECT COUNT(*) FROM matriculas WHERE curso_id = ? AND estado = 'ACTIVA'", (c,)).fetchone()[0]
        self.assertEqual(activas, 5)

    def test_mismo_estudiante_repetido_solo_entra_una_vez(self):
        c = self.curso("A1", cupo=10)
        e = self.estudiante()
        resultados = self._rafaga(c, [e] * 12)
        self.assertEqual(resultados.count(201), 1)
        activas = self.con.execute("SELECT COUNT(*) FROM matriculas WHERE estudiante_id = ?", (e,)).fetchone()[0]
        self.assertEqual(activas, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
